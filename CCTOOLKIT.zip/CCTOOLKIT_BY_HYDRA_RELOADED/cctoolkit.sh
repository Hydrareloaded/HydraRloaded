python /usr/bin/cctoolkit/starting.py
