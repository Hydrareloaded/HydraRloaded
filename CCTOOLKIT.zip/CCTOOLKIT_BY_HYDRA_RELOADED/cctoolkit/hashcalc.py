import cctoolkit

def welcome():
    print'''Choose One Of The Following Hashes To Render Your String
        1.  MD5
        2.  SHA-1
        3.  SHA-224
        4.  SHA-256
        5.  SHA-384
        6.  SHA-512
       99.  EXIT

'''

    try:
        userinpu = raw_input("cctoolkit> ")
        userinput = int(userinpu)

        if userinput == 1:
            cctoolkit.hashmd5()
        elif userinput == 2:
            cctoolkit.hashsha1()
        elif userinput == 3:
            cctoolkit.hashsha224()
        elif userinput == 4:
            cctoolkit.hashsha256()
        elif userinput == 5:
            cctoolkit.hashsha384()
        elif userinput == 6:
            cctoolkit.hashsha512()
        elif userinput == 99:
            print "\nProgram will Now Terminate. See You Again.."
            exit()
    except ValueError: 
        print "\nThe Value Expected Of You Was Incorrect. \nProgram will Exit"
        exit()
    except SyntaxError:
        print "\nThere Has Been A Syntax Error, And Program Will Exit."
        exit()
    except Exception as e:
        print "\nThere Has Been An Error In Your Input"
        exit()
