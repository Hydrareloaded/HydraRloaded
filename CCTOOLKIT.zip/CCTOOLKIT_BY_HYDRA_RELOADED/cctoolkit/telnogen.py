def localnum():
    x = "0"

    b = 0

    userinp1=raw_input("\nEnter The Starting Number. E.g 0200000000: ")
    userinp2=raw_input("\nEnter The Ending Number. E.g 0209999999: ")
    userinput3=raw_input("\nEnter The Path To Save Your File: ")
    print "\n"
    userinput1=int(userinp1)
    userinput2=int(userinp2)
    
    paths="{}".format(userinput3)
    a=paths
 
    file1=open("{}".format(a), 'w')


    while b>=0:
        user1 = str(userinput1)
        user2 = str(userinput2)
        userinput1 += 1
        print x+user1
        calc = x+user1+"\n"

        call = calc

        file1.write(call)
        
        if user1 == user2:
            print "\nThe Generation is Complete \nGo To The Directory You Specified To See You Output"
            break

    file1.close()


def countrynum():
    x = "+"

    b = 0

    userinp1=raw_input("\nEnter The Starting Number With Country Code. E.g 2332448394021: ")
    userinp2=raw_input("\nEnter The Ending Number With Country Code. E.g 2332448394021: ")
    userinput3=raw_input("\nEnter The Path To Save Your File: ")
    print "\n"
    userinput1=int(userinp1)
    userinput2=int(userinp2)
    
    paths="{}".format(userinput3)
    a=paths
 
    file1=open("{}".format(a), 'w')


    while b>=0:
        user1 = str(userinput1)
        user2 = str(userinput2)
        userinput1 += 1
        print x+user1
        calc = x+user1+"\n"

        call = calc

        file1.write(call)
        
        if user1 == user2:
            print "\nThe Generation is Complete \nGo To The Directory You Specified To See You Output"
            break

    file1.close()


def welcome():
    print '''
THIS PART GENERATES TELPHONE NUMBERS FOR YOU, SO THAT YOU CAN USE
IT FOR YOUR PURPOSE. WHETHER TO USE IT AS A PASSWORD LIST OR WHATEVER.

THERE ARE TWO PATTERNS FOR GENERATING THE TELEPHONE NUMBER LIST.

ONE IS BY COUNTRY CODE, AND THE OTHER IS GENERATED NORMALLY AS A LOCAL
NUMBER, WHICH WILL START WITH ZERO(0)

Choose From The Alternatives To Continue:

      1.  LOCAL NUMBER GENERATOR (generate local numbers, which starts with zero(0))
      2.  COUNTRY CODE INCLUDE NUMBER (starts with +)

'''
    try:
        userinp1=raw_input("cctoolkit> ")
        userinput1=int(userinp1)
 
        if userinput1 == 1:
            localnum()
        elif userinput1 == 2:
            countrynum()
        else:
            print "\nThere Has Been An Error. \nProgram Will Exit"


    except ValueError:
        print "\nYou Entered A Wrong Figure \nProgram Will Exit..."

    except SyntaxError:
        print "\nThere Has Been A Syntax Error \nProgram Will Exit..."

    except Exception as e:
        print "\nThere Has Been An Error \nRerun The Program ... "


