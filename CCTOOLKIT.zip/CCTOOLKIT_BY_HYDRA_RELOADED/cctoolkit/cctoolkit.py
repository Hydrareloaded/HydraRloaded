import hashlib
import os
import sys

def md5_pwcracker():
    print'''
THIS PASSWORD CRACKER SUPPORT ONLY MD5 HASHES, AND SUPPORTS ONLY DICTIONARY
ATTACKS.
YOU HAVE TO PROVIDE THE PASSWORD HASHES TO BE CRACKED AS WELL A DICTIONARY 
FILE TO BE RUN AGAINST THE HASHES
'''

    import md5

    counter = 1

    pass_in = raw_input("Enter The MD5 Hash: ")
    passwordfile = raw_input("Specify The Path To Your Password File: ")

    try:
        passwordfile = open(passwordfile, "r")
    except:
        print "\nPassword file Not Found. \nIts Either You Entered A Wrong Path, Or The File Does Not Exist! \nProgram will exit..."
        quit()

    for password in passwordfile:
        md5file = md5.new(password.strip()).hexdigest()
        print "Trying password number %d: %s "%(counter, password.strip())
        counter += 1

        if pass_in == md5file:
            print "\nMatch Found. \nPassword is: %s" % password
            break

    else: print "\nPassword Not Found. \nYou May Try Another Dictionary"



def sha1_pwcracker():

    print'''
THIS PASSWORD CRACKER SUPPORT ONLY MD5 HASHES, AND SUPPORTS ONLY DICTIONARY
ATTACKS.
YOU HAVE TO PROVIDE THE PASSWORD HASHES TO BE CRACKED AS WELL A DICTIONARY 
FILE TO BE RUN AGAINST THE HASHES
'''

    #import hashlib

    counter = 1

    hashcode = raw_input("Enter The Sha-1 Hash: ")
    pwfinput = raw_input("Specify The Path To Your Password File: ")

    try:
        pwfile = open (pwfinput, "r")

    except:
        print "\nPassword file Not Found. \nIts Either You Entered A Wrong Path, Or The File Does Not Exist! \nProgram will exit..."
        quit()


    for x in pwfile:
        no1 = hashlib.sha1(x.strip())
        no2 = no1.hexdigest()
        print "Trying password number %d: %s "%(counter, x.strip())
        counter += 1
        
        if hashcode == no2:
            print "\nMatch Found. \nPassword is: %s" % x
            exit()

    else:
        print "\nPassword Not Found. \nYou May Try Another Dictionary"



def sha224_pwcracker():
    print'''
THIS PASSWORD CRACKER SUPPORT ONLY SHA-224 HASHES, AND SUPPORTS ONLY DICTIONARY
ATTACKS.
YOU HAVE TO PROVIDE THE PASSWORD HASHES TO BE CRACKED AS WELL A DICTIONARY 
FILE TO BE RUN AGAINST THE HASHES
'''

    #import hashlib

    counter = 1

    hashcode = raw_input("Enter The Sha-224 Hash: ")
    pwfinput = raw_input("Specify The Path To Your Password File: ")

    try:
        pwfile = open (pwfinput, "r")

    except:
        print "\nPassword file Not Found. \nIts Either You Entered A Wrong Path, Or The File Does Not Exist! \nProgram will exit..."
        quit()


    for x in pwfile:
        no1 = hashlib.sha224(x.strip())
        no2 = no1.hexdigest()
        print "Trying password number %d: %s "%(counter, x.strip())
        counter += 1
        
        if hashcode == no2:
            print "\nMatch Found. \nPassword is: %s" % x
            exit()

    else:
        print "\nPassword Not Found. \nYou May Try Another Dictionary"


def sha256_pwcracker():
    print'''
THIS PASSWORD CRACKER SUPPORT ONLY SHA-256 HASHES, AND SUPPORTS ONLY DICTIONARY
ATTACKS.
YOU HAVE TO PROVIDE THE PASSWORD HASHES TO BE CRACKED AS WELL A DICTIONARY 
FILE TO BE RUN AGAINST THE HASHES
'''

    #import hashlib

    counter = 1

    hashcode = raw_input("Enter The Sha-256 Hash: ")
    pwfinput = raw_input("Specify The Path To Your Password File: ")

    try:
        pwfile = open (pwfinput, "r")

    except:
        print "\nPassword file Not Found. \nIts Either You Entered A Wrong Path, Or The File Does Not Exist! \nProgram will exit..."
        quit()


    for x in pwfile:
        no1 = hashlib.sha256(x.strip())
        no2 = no1.hexdigest()
        print "Trying password number %d: %s "%(counter, x.strip())
        counter += 1
        
        if hashcode == no2:
            print "\nMatch Found. \nPassword is: %s" % x
            exit()

    else:
        print "\nPassword Not Found. \nYou May Try Another Dictionary"


def sha384_pwcracker():
    print'''
THIS PASSWORD CRACKER SUPPORT ONLY SHA-384 HASHES, AND SUPPORTS ONLY DICTIONARY
ATTACKS.
YOU HAVE TO PROVIDE THE PASSWORD HASHES TO BE CRACKED AS WELL A DICTIONARY 
FILE TO BE RUN AGAINST THE HASHES
'''

    import hashlib

    counter = 1

    hashcode = raw_input("Enter The Sha-384 Hash: ")
    pwfinput = raw_input("Specify The Path To Your Password File: ")

    try:
        pwfile = open (pwfinput, "r")

    except:
        print "\nPassword file Not Found. \nIts Either You Entered A Wrong Path, Or The File Does Not Exist! \nProgram will exit..."
        quit()


    for x in pwfile:
        no1 = hashlib.sha384(x.strip())
        no2 = no1.hexdigest()
        print "Trying password number %d: %s "%(counter, x.strip())
        counter += 1
        
        if hashcode == no2:
            print "\nMatch Found. \nPassword is: %s" % x
            exit()

    else:
        print "\nPassword Not Found. \nYou May Try Another Dictionary"



def sha512_pwcracker():
    print'''
THIS PASSWORD CRACKER SUPPORT ONLY SHA-512 HASHES, AND SUPPORTS ONLY DICTIONARY
ATTACKS.
YOU HAVE TO PROVIDE THE PASSWORD HASHES TO BE CRACKED AS WELL A DICTIONARY 
FILE TO BE RUN AGAINST THE HASHES
'''

    import hashlib

    counter = 1

    hashcode = raw_input("Enter The Sha-512 Hash: ")
    pwfinput = raw_input("Specify The Path To Your Password File: ")

    try:
        pwfile = open (pwfinput, "r")

    except:
        print "\nPassword file Not Found. \nIts Either You Entered A Wrong Path, Or The File Does Not Exist! \nProgram will exit..."
        quit()


    for x in pwfile:
        no1 = hashlib.sha512(x.strip())
        no2 = no1.hexdigest()
        print "Trying password number %d: %s "%(counter, x.strip())
        counter += 1
        
        if hashcode == no2:
            print "\nMatch Found. \nPassword is: %s" % x
            exit()

    else:
        print "\nPassword Not Found. \nYou May Try Another Dictionary"




def pingen():
    wlcm = '''
THE PIN GENERATOR HELPS GENERATE A RANGE OF PINCODES OR NUMBERS
FOR YOU IN A TEXT FILE. YOU CAN USE THIS TEXT FILE THEN FOR YOUR
PURPOSE...

NOTE:  You are required to a starting number and a last number
The program will then generate all the numbers between the
starting number you provided and the last number you provided...

''' 
    try:
        print(wlcm)
        usip1 = input('Enter A Starting Number: ')
        usip2 = input('Enter A Last Number: ')
        location = raw_input("\nEnter The Path To Save Your Output.\nExample: '/root/Desktop/file.txt':  ")
        paths = "{}".format(location)
        a=paths
        print("\n")
        file1 = open("{}".format(a), 'w')
        go = str(usip1)
        justify = go + '\n'
        file1.write(justify)

        while usip1 >= 0:
            
            #print (usip1)
            usip1 += 1
            quotion = str(usip1)
            final = quotion + '\n'
            file1.write(final)
            if usip1 == usip2:
                #print(usip2)
                print
                print("Generation has been completed successfully. Check {} for your output".format(location))
                break
    except ValueError:
        print("You Entered An Incorrect Figure. Program Will Terminate...\n")
        exit()
    except TypeError:
        print("You Entered An Incorrect Figure. Program Will Terminate...\n")
        exit()
    except SyntaxError:
        print("There has been a Syntax Error. Please re-run the Program\n")
        exit()
    except Exception as e:
        print("\nThere has been an Error in your input and the Program will now exit\nCheck that the first input you provided is an integer\nIf you have done that and still getting an error,\nYou can send me an email 'messianicbenyitzchak@gmail.com'\nAnd i will help you... \nThank You!\n")
        exit()



def hashmd5():

    userinput = raw_input("Enter String To Be Hashed: ")
    x = hashlib.md5(userinput)
    a = x.hexdigest()
    print "\nYour Text Was Decrypted As: \n", a

def hashsha1():

    userinput = raw_input("Enter String To Be Hashed: ")
    x = hashlib.sha1(userinput)
    a = x.hexdigest()
    print "\nYour Text Was Decrypted As: \n", a

def hashsha224():

    userinput = raw_input("Enter String To Be Hashed: ")
    x = hashlib.sha224(userinput)
    a = x.hexdigest()
    print "\nYour Text Was Decrypted As: \n", a

def hashsha256():

    userinput = raw_input("Enter String To Be Hashed: ")
    x = hashlib.sha256(userinput)
    a = x.hexdigest()
    print "\nYour Text Was Decrypted As: \n", a

def hashsha384():

    userinput = raw_input("Enter String To Be Hashed: ")
    x = hashlib.sha384(userinput)
    a = x.hexdigest()
    print "\nYour Text Was Decrypted As: \n", a

def hashsha512():

    userinput = raw_input("Enter String To Be Hashed: ")
    x = hashlib.sha512(userinput)
    a = x.hexdigest()
    print "\nYour Text Was Decrypted As: \n", a

