import telnogen
import halfgen

print '''

    CCRACK TOOLKIT

=       =    =           ========    =       =
=       =    =           =           = =   = =
=       =    =           =           =   =   =
=   =   =    =           =           =       =
= =   = =    =           =           =       =
=       =    ========    ========    =       =

    CCRACK TOOLKIT

                  =
                   = 
               =     =  = = = = = =
                                  =
                                  = 
                                  =
                                  =

WELCOME TO CCRACK TOOLKIT DEVELOPED BY CHRISTIAN ADOKOH. THIS PROGRAM WAS
MADE TO PROVIDE NOOBS WITH COMFORT IN THE WORLD OF PROGRAMMING. 
THE PROGRAM HAS MANY USES AND AGAIN, IT WAS DESIGNED FOR NOOBS.
IF YOU ARE A PRO, YOU CAN LOOK ON TO MORE ADVANCE TOOLS WHERE SOME EVEN
SUPPORT RAINBOW CRACKING AND MORE

READ THE NOTES ON ANY SECTION, IF THERE IS. ITS IMPORTANT. IT GIVES YOU
AN IMPORTANT GIST ABOUT THE SECTION AND HOW TO PROCEED.

DISCLAIMER:  ALL THIS TOOL IS MEANT FOR EDUCATIONAL PURPOSE ONLY.
BY NO MEANS MUST IT BE USED TO HARM.
I WILL NOT BE RESPONSIBLE FOR ANY HARM CAUSED BY ANY MISUSE OF THIS 
APPLICATION.


Choose One Of The Options Below To Proceed With CCRACK Toolkit:

       1.  PIN GENERATOR
       2.  HASH GENERATOR
       3.  HASH CRACKER
       4.  TELEPHONE NUMBER GENERATOR
       5.  PASSWORD APPEND
      99.  EXIT

'''
import sys
sys.path.append("/usr/bin/cctoolkit")
import cctoolkit
import hashcalc
import hashcrack

try: 
    userinp=raw_input("cctoolkit> ")
    userinput=int(userinp)

    if userinput == 1:
        cctoolkit.pingen()
    
    elif userinput == 2:
        hashcalc.welcome()

    elif userinput == 3:
        hashcrack.launch()

    elif userinput == 4:
        telnogen.welcome()

    elif userinput == 5:
        halfgen.appendpass()

    elif userinput == 99:
        print "\nProgram Will Now Terminate. \nThank You For You Time\n"
        exit()
    else:
        print "\nNo Better Option\n"

except ValueError:
    print "\nYou Entered An Invalid Value And Program Will Exit\n"
    exit()

except SyntaxError:
    print "\nYou Have Entered A Wrong Syntax And The Program Will Exit\n"
    exit()

except Exception as e:
    print "\nThere Has Been An Error In You Input. \nPlease Run The Program Again\n"
