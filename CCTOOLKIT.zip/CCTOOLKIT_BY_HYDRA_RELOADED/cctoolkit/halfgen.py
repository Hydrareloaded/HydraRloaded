def appendpass():

    print '''
THIS PART OF THE TOOL HELPS YOU TO APPEND NUMBERS TO A WORD.
THIS IS VERY USEFUL IF YOU REMEMBER THE WORD IN A PASSWORD, 
BUT HAVE FORGOTTEN THE FIGURES THAT FOLLOW.

YOU CAN USE THIS TOOL TO GENERATE NUMBERS AND SAVE THEM AS
A WORDLIST.

IT CAN THEN BE RUN AGAINST THE LOGIN OR HASH.'''

    a = 0

    x = raw_input("\nEnter The Word You Want To Append: ")
    y = raw_input("\nEnter The Number You Want To Start Appending With: ")
    z = raw_input("\nEnter The Number You Want To End With: ")
    location = raw_input("\nEnter The Path To Save Your Output: ")

    xy = int(y)
    yz = int(z)
    
    try: 
        file1=open("{}".format(location), 'w')
    except Exception as e:
        print "\nThe File Could Not Be Found. \nIt's Either The File Does Not Exist OR \nThe Path Does Not Exist..."
        exit()

    opt = str(z)
    name = str(x)
    names = name+z

    try:
        while a>=0:

            var = str(xy)
            print name+var
            lub = name+var+"\n"
        
            file1.write(lub)

            xy += 1

            if xy == yz:
                print(names)
                file1.write(names)
                break
        
    
        file1.close()

    except ValueError:
        print "\nYou Must Specify A Value: \nRerun The Program...\n"
        exit()

    except SyntaxError:
        print "\nThere Has Been An Error In Your Syntax \nPlease Run The Program Again\n"
        exit()

    except Exception as e:
        print "\nThere Has Been An Error And The Program Must Quit\n "        


