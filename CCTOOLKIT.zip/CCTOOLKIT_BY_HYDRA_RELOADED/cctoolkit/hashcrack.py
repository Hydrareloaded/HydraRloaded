import cctoolkit

def launch():
    print'''
Note:    To Be Able To Crack Hashes You Need To Provide A Password
File, In Order Words, A Dictionary File.
Your Chance To Be Able To Crack Any Hash Depends On How Large And
Good Your Wordlist is...

Make Sure Also To Choose The Righ Hash Algorithm. If You Are Unsure
What Hash Type You Have, Do Research On Hash Algorithms And Get To
Know them... If You Enter A Different Hash Algorithm, Password
Check Will Run Though, But The Correct Password Will Never Be Found.

    # GOOD LUCK!! #

Choose One Of The Following Types Of Hashes To Crack:

       1.  MD5
       2.  SHA-1
       3.  SHA-224
       4.  SHA-256
       5.  SHA-384
       6.  SHA-512
      99.  EXIT

'''

    try:
        userinpu = raw_input("cctoolkit> ")
        userinput = int(userinpu)

        if userinput == 1:
            cctoolkit.md5_pwcracker()
        elif userinput == 2:
            cctoolkit.sha1_pwcracker()
        elif userinput == 3:
            cctoolkit.sha224_pwcracker()
        elif userinput == 4:
            cctoolkit.sha256_pwcracker()
        elif userinput == 5:
            cctoolkit.sha384_pwcracker()
        elif userinput == 6:
            cctoolkit.sha512_pwcracker()
        elif userinput == 99:
            print "\nProgram will Now Terminate. See You Again.."
            exit()
    except ValueError: 
        print "\nThe Value Expected Of You Was Incorrect. \nProgram will Exit"
        exit()
    except SyntaxError:
        print "\nThere Has Been A Syntax Error, And Program Will Exit."
        exit()
    except Exception as e:
        print "\nThere Has Been An Error In Your Input"
        exit()
